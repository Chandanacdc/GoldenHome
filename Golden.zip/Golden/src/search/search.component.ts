import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  public searchText : string;
  public customerData : any;

  constructor() { }

  ngOnInit() {
    this.customerData = [
      {"place": 'HSR Layout', "One": 8000, "Two":7000, "Three":6000, "Four":5000, "faci":'Tv, wifi, Food, kitchen' },
      {"place": 'Koramongola', "One": 7500, "Two":6500, "Three":5500, "Four":4000, "faci":'Tv, wifi, Food, kitchen'},
      {"place": 'BTM Layout', "One": 8000, "Two":7000, "Three":6000, "Four":5000, "faci":'Tv, wifi, Food, kitchen'},
      {"place": 'Marathali', "One": 10000, "Two":9000, "Three":7000, "Four":5000, "faci":'Tv, wifi, Food, kitchen'},
      {"place": 'Madiwala', "One": 8000, "Two":7000, "Three":6000, "Four":5000, "faci":'Tv, wifi, Food, kitchen'},
      {"place": 'Silkboard', "One": 8000, "Two":7000, "Three":6000, "Four":5000, "faci":'Tv, wifi, Food, kitchen'},
      {"place": 'Bommanahalli',"One": 8000, "Two":7000, "Three":6000, "Four":5000, "faci":'Tv, wifi, Food, kitchen'}];
  }
}