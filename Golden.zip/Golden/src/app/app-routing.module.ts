import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from 'src/home/home.component';

import { ScheduleComponent } from 'src/schedule/schedule.component';
import { SearchComponent } from 'src/search/search.component';


const routes: Routes = [
  {path:'home', component:HomeComponent},
  {path:'schedule', component:ScheduleComponent},
  {path:'search', component:SearchComponent},
  
  {path:'',component:HomeComponent},
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }