import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import{ ProjectComponent } from '../project/project.component';
import{ HomeComponent } from '../home/home.component';
import{ ScheduleComponent } from '../schedule/schedule.component';
import { SearchComponent } from '../search/search.component';
import { GrdFilterPipe } from '../search/search.pipe';
import { ErrorComponent } from '../error/error.component'

// search module




@NgModule({
  declarations: [
    AppComponent,ProjectComponent,HomeComponent,ScheduleComponent,SearchComponent,GrdFilterPipe,ErrorComponent
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
