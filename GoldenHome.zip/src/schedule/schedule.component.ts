import { Component } from '@angular/core';

@Component({
  selector: 'schedule',
  templateUrl: 'schedule.component.html',
  styleUrls:['schedule.component.css']
})

export class ScheduleComponent {
  model: any = {};

  onSubmit() {
    alert('SUCCESS!! \n\n We will send a time in Email for visiting'),
    window.open('app.component.html')
   
  }
}
